import React, { useState, useEffect } from 'react';
import { Menu, X, Search, ArrowRight, Mail, Linkedin, ChevronDown, Moon, Sun, ArrowUp } from 'lucide-react';

export default function BusinessClubWebsite() {
  const [activePage, setActivePage] = useState('home');
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [darkMode, setDarkMode] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const [showBackToTop, setShowBackToTop] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 20);
      setShowBackToTop(window.scrollY > 300);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navItems = [
    { id: 'home', label: 'Home', icon: '🏠' },
    { id: 'insights', label: 'Insights', icon: '📰' },
    { id: 'career', label: 'Career Hub', icon: '💼' },
    { id: 'shark', label: 'Shark Tank', icon: '🦈' },
    { id: 'helpdesk', label: 'Help Desk', icon: '❓' },
    { id: 'team', label: 'Our Team', icon: '👥' },
  ];

  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const bgClass = darkMode ? 'bg-gray-950 text-white' : 'bg-white text-gray-900';
  const sidebarBg = darkMode ? 'bg-gray-900 border-gray-800' : 'bg-gradient-to-b from-blue-900 to-blue-800';
  const cardBg = darkMode ? 'bg-gray-900' : 'bg-white';
  const borderColor = darkMode ? 'border-gray-800' : 'border-gray-200';

  return (
    <div className={`flex h-screen ${bgClass} transition-colors duration-300`}>
      {/* Sidebar */}
      <div className={`${sidebarBg} w-64 flex flex-col border-r ${borderColor} fixed left-0 top-0 h-full z-40 transition-all ${!sidebarOpen && 'max-md:-translate-x-full'}`}>
        <div className="p-6 border-b border-gray-700">
          <h1 className="text-2xl font-bold text-white">BMC</h1>
          <p className="text-blue-100 text-sm mt-1">Business Management Club</p>
        </div>
        
        <nav className="flex-1 p-4 space-y-2">
          {navItems.map((item) => (
            <button
              key={item.id}
              onClick={() => {
                setActivePage(item.id);
                setSidebarOpen(false);
              }}
              className={`w-full text-left px-4 py-3 rounded-lg transition-all flex items-center gap-3 ${
                activePage === item.id
                  ? 'bg-yellow-400 text-blue-900 font-semibold'
                  : 'text-blue-100 hover:bg-blue-700'
              }`}
            >
              <span className="text-xl">{item.icon}</span>
              <span>{item.label}</span>
            </button>
          ))}
        </nav>

        <div className="p-4 border-t border-gray-700">
          <div className="text-blue-100 text-sm space-y-2">
            <p>📧 contact@bmc.sis.edu</p>
            <p>📍 Singapore Int'l School</p>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="flex-1 ml-64 max-md:ml-0 overflow-auto">
        {/* Header */}
        <header className={`${cardBg} border-b ${borderColor} sticky top-0 z-30 backdrop-blur`}>
          <div className="flex items-center justify-between px-6 py-4">
            <div className="flex items-center gap-4">
              <button onClick={() => setSidebarOpen(!sidebarOpen)} className="md:hidden p-2 hover:bg-gray-200 dark:hover:bg-gray-800 rounded-lg">
                {sidebarOpen ? <X size={24} /> : <Menu size={24} />}
              </button>
              <div className="hidden md:flex items-center flex-1 max-w-sm bg-gray-100 dark:bg-gray-800 rounded-lg px-4 py-2">
                <Search size={18} className="text-gray-400" />
                <input type="text" placeholder="Search articles..." className="bg-transparent ml-2 outline-none w-full text-sm" />
              </div>
            </div>
            
            <div className="flex items-center gap-4">
              <button onClick={() => setDarkMode(!darkMode)} className="p-2 hover:bg-gray-200 dark:hover:bg-gray-800 rounded-lg">
                {darkMode ? <Sun size={20} /> : <Moon size={20} />}
              </button>
            </div>
          </div>
        </header>

        <div className="p-6 max-w-6xl mx-auto">
          {/* HOME */}
          {activePage === 'home' && (
            <div className="space-y-12">
              <div className="relative h-96 bg-gradient-to-r from-blue-900 via-blue-800 to-blue-700 rounded-2xl p-12 text-white overflow-hidden">
                <div className="absolute -right-20 -top-20 w-64 h-64 bg-yellow-400 rounded-full opacity-10"></div>
                <div className="relative z-10">
                  <h1 className="text-5xl font-bold mb-4">Build. Create. Lead.</h1>
                  <p className="text-xl text-blue-100 mb-8 max-w-2xl">Unleash your entrepreneurial potential with the Business Management Club at Singapore International School. Learn real business skills, compete in Shark Tank, and build the future.</p>
                  <div className="flex gap-4">
                    <button onClick={() => setActivePage('shark')} className="bg-yellow-400 hover:bg-yellow-300 text-blue-900 font-semibold px-8 py-3 rounded-lg transition flex items-center gap-2">
                      Join Shark Tank <ArrowRight size={20} />
                    </button>
                    <button onClick={() => setActivePage('insights')} className="border-2 border-white text-white hover:bg-white hover:text-blue-900 font-semibold px-8 py-3 rounded-lg transition">
                      Read Insights
                    </button>
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                {[
                  { number: '200+', label: 'Active Members' },
                  { number: '15', label: 'Workshops/Year' },
                  { number: '$50K', label: 'Prize Pool' }
                ].map((stat, i) => (
                  <div key={i} className={`${cardBg} p-8 rounded-xl border ${borderColor} text-center hover:shadow-lg transition`}>
                    <div className="text-4xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-blue-600 to-yellow-400">{stat.number}</div>
                    <p className="text-gray-600 dark:text-gray-400 mt-2">{stat.label}</p>
                  </div>
                ))}
              </div>

              <div>
                <h2 className="text-3xl font-bold mb-6">Upcoming Events</h2>
                <div className="grid gap-4">
                  {[
                    { title: 'Shark Tank Finals', date: 'March 15', desc: 'Watch the best business pitches compete' },
                    { title: 'Resume Workshop', date: 'March 8', desc: 'Learn to craft the perfect business resume' },
                    { title: 'Finance Fundamentals', date: 'March 1', desc: 'Introduction to business accounting' }
                  ].map((event, i) => (
                    <div key={i} className={`${cardBg} p-6 rounded-xl border ${borderColor} flex justify-between items-center hover:shadow-lg transition`}>
                      <div>
                        <h3 className="font-semibold text-lg">{event.title}</h3>
                        <p className="text-gray-600 dark:text-gray-400 text-sm">{event.desc}</p>
                      </div>
                      <span className="bg-yellow-100 dark:bg-yellow-900 text-yellow-800 dark:text-yellow-200 px-4 py-2 rounded-lg font-medium whitespace-nowrap ml-4">{event.date}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* INSIGHTS (Blog) */}
          {activePage === 'insights' && (
            <div className="space-y-8">
              <div>
                <h1 className="text-4xl font-bold mb-2">Insights</h1>
                <p className="text-gray-600 dark:text-gray-400">Articles on business, entrepreneurship, and leadership</p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {[
                  {
                    title: 'The Future of Startups in 2024',
                    author: 'Rajesh Kumar',
                    date: 'Feb 28, 2024',
                    image: '📈',
                    excerpt: 'Exploring emerging trends in entrepreneurship and tech innovation'
                  },
                  {
                    title: 'Personal Finance 101',
                    author: 'Ananya Patel',
                    date: 'Feb 25, 2024',
                    image: '💰',
                    excerpt: 'Master the basics of budgeting, investing, and wealth building'
                  },
                  {
                    title: 'Leadership Lessons from Failed Startups',
                    author: 'Marco Rossi',
                    date: 'Feb 20, 2024',
                    image: '📚',
                    excerpt: 'What we learned from companies that didn\'t make it'
                  },
                  {
                    title: 'Networking Like a Pro',
                    author: 'Zara Chen',
                    date: 'Feb 18, 2024',
                    image: '🤝',
                    excerpt: 'How to build meaningful connections in the business world'
                  }
                ].map((post, i) => (
                  <div key={i} className={`${cardBg} rounded-xl border ${borderColor} overflow-hidden hover:shadow-xl transition group cursor-pointer`}>
                    <div className={`h-40 bg-gradient-to-br ${i % 2 === 0 ? 'from-blue-100 to-blue-50' : 'from-yellow-100 to-yellow-50'} dark:from-gray-800 dark:to-gray-700 flex items-center justify-center text-6xl`}>
                      {post.image}
                    </div>
                    <div className="p-6">
                      <h3 className="font-bold text-lg mb-2 group-hover:text-blue-600 transition">{post.title}</h3>
                      <p className="text-sm text-gray-600 dark:text-gray-400 mb-4">{post.excerpt}</p>
                      <div className="flex justify-between items-center text-xs text-gray-500 dark:text-gray-500">
                        <span>{post.author} • {post.date}</span>
                        <button className="text-blue-600 hover:text-blue-800 font-semibold">Read More →</button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* CAREER HUB */}
          {activePage === 'career' && (
            <div className="space-y-8">
              <div>
                <h1 className="text-4xl font-bold mb-2">Career Hub</h1>
                <p className="text-gray-600 dark:text-gray-400">Your guide to business education and professional development</p>
              </div>

              <div className="grid gap-6">
                {[
                  { icon: '📄', title: 'Resume Building', desc: 'Create a standout resume with our templates and tips' },
                  { icon: '🎓', title: 'College Prep', desc: 'Business major application strategies and essays' },
                  { icon: '💼', title: 'Internship Guide', desc: 'How to find and land your first internship' },
                  { icon: '🏆', title: 'Leadership Skills', desc: 'Develop the skills top business schools want' }
                ].map((resource, i) => (
                  <div key={i} className={`${cardBg} p-8 rounded-xl border ${borderColor} hover:shadow-lg transition group cursor-pointer`}>
                    <div className="flex gap-6 items-start">
                      <div className="text-5xl">{resource.icon}</div>
                      <div className="flex-1">
                        <h3 className="text-xl font-bold mb-2 group-hover:text-blue-600 transition">{resource.title}</h3>
                        <p className="text-gray-600 dark:text-gray-400 mb-4">{resource.desc}</p>
                        <button className="text-blue-600 hover:text-blue-800 font-semibold text-sm flex items-center gap-2">
                          Explore <ArrowRight size={16} />
                        </button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>

              <div className={`${cardBg} p-8 rounded-xl border ${borderColor} bg-gradient-to-br from-blue-50 to-blue-100 dark:from-blue-900 dark:to-blue-800`}>
                <h3 className="text-2xl font-bold mb-4">Sample Resume Template</h3>
                <p className="text-gray-700 dark:text-gray-300 mb-4">Download our professional resume template tailored for high school students</p>
                <button className="bg-blue-600 hover:bg-blue-700 text-white px-6 py-2 rounded-lg font-semibold">Download Template</button>
              </div>
            </div>
          )}

          {/* SHARK TANK */}
          {activePage === 'shark' && (
            <div className="space-y-8">
              <div className="bg-gradient-to-r from-yellow-400 to-yellow-300 text-gray-900 rounded-2xl p-12">
                <h1 className="text-5xl font-bold mb-2">🦈 Shark Tank</h1>
                <p className="text-lg opacity-90">Pitch your business idea to our investor panel</p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                <div>
                  <h2 className="text-2xl font-bold mb-6">Event Details</h2>
                  <div className="space-y-4">
                    {[
                      { label: 'Date', value: 'March 15, 2024' },
                      { label: 'Time', value: '6:00 PM - 8:00 PM' },
                      { label: 'Location', value: 'School Auditorium' },
                      { label: 'Prize Pool', value: '$50,000' }
                    ].map((detail, i) => (
                      <div key={i} className={`${cardBg} p-4 rounded-lg border ${borderColor}`}>
                        <p className="text-sm text-gray-600 dark:text-gray-400">{detail.label}</p>
                        <p className="font-bold text-lg">{detail.value}</p>
                      </div>
                    ))}
                  </div>
                </div>

                <div>
                  <h2 className="text-2xl font-bold mb-6">Timeline</h2>
                  <div className="space-y-4">
                    {[
                      { phase: 'Applications Open', date: 'Feb 1' },
                      { phase: 'Deadline', date: 'Feb 28' },
                      { phase: 'Semi-Finals', date: 'March 8' },
                      { phase: 'Grand Finals', date: 'March 15' }
                    ].map((item, i) => (
                      <div key={i} className="flex items-center gap-4">
                        <div className="w-3 h-3 bg-yellow-400 rounded-full"></div>
                        <div>
                          <p className="font-semibold">{item.phase}</p>
                          <p className="text-sm text-gray-600 dark:text-gray-400">{item.date}</p>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>

              <div className={`${cardBg} p-8 rounded-xl border ${borderColor}`}>
                <h2 className="text-2xl font-bold mb-6">Application Form</h2>
                <form className="space-y-6">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                      <label className="block font-semibold mb-2">Full Name *</label>
                      <input type="text" required className={`w-full px-4 py-2 rounded-lg border ${borderColor} bg-transparent`} />
                    </div>
                    <div>
                      <label className="block font-semibold mb-2">Grade *</label>
                      <select required className={`w-full px-4 py-2 rounded-lg border ${borderColor} bg-transparent`}>
                        <option>Select Grade</option>
                        <option>9</option>
                        <option>10</option>
                        <option>11</option>
                        <option>12</option>
                      </select>
                    </div>
                  </div>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                      <label className="block font-semibold mb-2">Email *</label>
                      <input type="email" required className={`w-full px-4 py-2 rounded-lg border ${borderColor} bg-transparent`} />
                    </div>
                    <div>
                      <label className="block font-semibold mb-2">Team Name *</label>
                      <input type="text" required className={`w-full px-4 py-2 rounded-lg border ${borderColor} bg-transparent`} />
                    </div>
                  </div>
                  <div>
                    <label className="block font-semibold mb-2">Business Idea (2-3 sentences) *</label>
                    <textarea required className={`w-full px-4 py-2 rounded-lg border ${borderColor} bg-transparent h-24`}></textarea>
                  </div>
                  <div>
                    <label className="block font-semibold mb-2">Problem Being Solved *</label>
                    <textarea required className={`w-full px-4 py-2 rounded-lg border ${borderColor} bg-transparent h-20`}></textarea>
                  </div>
                  <div>
                    <label className="block font-semibold mb-2">Upload Pitch Deck (PDF)</label>
                    <input type="file" accept=".pdf" className={`w-full px-4 py-2 rounded-lg border ${borderColor} bg-transparent`} />
                  </div>
                  <button type="submit" className="w-full bg-gradient-to-r from-yellow-400 to-yellow-300 hover:from-yellow-300 hover:to-yellow-200 text-gray-900 font-bold py-3 rounded-lg transition">
                    Submit Application
                  </button>
                </form>
              </div>
            </div>
          )}

          {/* HELP DESK */}
          {activePage === 'helpdesk' && (
            <div className="space-y-8">
              <div>
                <h1 className="text-4xl font-bold mb-4">Help Desk</h1>
                <p className="text-gray-600 dark:text-gray-400 text-lg">Got questions about business concepts? We're here to help!</p>
              </div>

              <div className={`${cardBg} p-8 rounded-xl border ${borderColor} bg-gradient-to-br from-green-50 to-green-100 dark:from-green-900 dark:to-green-800`}>
                <h3 className="text-2xl font-bold mb-4">📝 Submit a Question</h3>
                <p className="text-gray-700 dark:text-gray-300 mb-6">Ask anything about business topics - no question is too small!</p>
                
                <form className="space-y-6">
                  <div>
                    <label className="block font-semibold mb-2">Your Name</label>
                    <input type="text" className={`w-full px-4 py-2 rounded-lg border ${borderColor} bg-transparent`} />
                  </div>

                  <div>
                    <label className="block font-semibold mb-2">Subject Area *</label>
                    <select required className={`w-full px-4 py-2 rounded-lg border ${borderColor} bg-transparent`}>
                      <option>Select a topic</option>
                      <option>Finance & Accounting</option>
                      <option>Marketing & Sales</option>
                      <option>Entrepreneurship</option>
                      <option>Operations</option>
                      <option>Leadership</option>
                      <option>Other</option>
                    </select>
                  </div>

                  <div>
                    <label className="block font-semibold mb-2">Your Question *</label>
                    <textarea required className={`w-full px-4 py-2 rounded-lg border ${borderColor} bg-transparent h-32`} placeholder="Write your question here..."></textarea>
                  </div>

                  <label className="flex items-center gap-3">
                    <input type="checkbox" className="w-4 h-4" />
                    <span className="text-sm">Submit anonymously</span>
                  </label>

                  <button type="submit" className="w-full bg-green-600 hover:bg-green-700 text-white font-bold py-3 rounded-lg transition">
                    Submit Question
                  </button>
                </form>
              </div>

              <div>
                <h3 className="text-2xl font-bold mb-6">FAQ</h3>
                <div className="space-y-4">
                  {[
                    { q: 'What is ROI?', a: 'Return on Investment measures profitability relative to investment cost' },
                    { q: 'How do I start a business?', a: 'Begin with market research, validate your idea, and develop a business plan' }
                  ].map((faq, i) => (
                    <details key={i} className={`${cardBg} p-4 rounded-lg border ${borderColor} cursor-pointer group`}>
                      <summary className="font-semibold flex justify-between items-center">
                        {faq.q}
                        <ChevronDown size={20} className="group-open:rotate-180 transition" />
                      </summary>
                      <p className="text-gray-600 dark:text-gray-400 mt-2">{faq.a}</p>
                    </details>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* OUR TEAM */}
          {activePage === 'team' && (
            <div className="space-y-8">
              <div>
                <h1 className="text-4xl font-bold mb-2">Meet The Team</h1>
                <p className="text-gray-600 dark:text-gray-400">Our passionate leadership team</p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {[
                  { name: 'Arjun Sharma', role: 'President', initials: 'AS', bio: 'Grade 12 • Passionate about startup ecosystems' },
                  { name: 'Priya Verma', role: 'VP Operations', initials: 'PV', bio: 'Grade 11 • Expert in event management' },
                  { name: 'Alex Kumar', role: 'VP Finance', initials: 'AK', bio: 'Grade 12 • Certified in financial analysis' },
                  { name: 'Sofia Martinez', role: 'Events Lead', initials: 'SM', bio: 'Grade 11 • Creative event organizer' },
                  { name: 'James Chen', role: 'Content Lead', initials: 'JC', bio: 'Grade 10 • Business writer & researcher' },
                  { name: 'Emma Wilson', role: 'Sponsorship Lead', initials: 'EW', bio: 'Grade 12 • Networking expert' }
                ].map((member, i) => (
                  <div key={i} className={`${cardBg} p-6 rounded-xl border ${borderColor} text-center hover:shadow-lg transition group`}>
                    <div className="w-16 h-16 bg-gradient-to-br from-blue-500 to-yellow-400 rounded-full flex items-center justify-center text-white font-bold text-xl mx-auto mb-4">
                      {member.initials}
                    </div>
                    <h3 className="font-bold text-lg">{member.name}</h3>
                    <p className="text-blue-600 dark:text-blue-400 font-semibold text-sm mb-2">{member.role}</p>
                    <p className="text-gray-600 dark:text-gray-400 text-sm mb-4">{member.bio}</p>
                    <div className="flex justify-center gap-3">
                      <button className="p-2 hover:bg-gray-200 dark:hover:bg-gray-800 rounded-lg transition">
                        <Linkedin size={18} className="text-blue-600" />
                      </button>
                      <button className="p-2 hover:bg-gray-200 dark:hover:bg-gray-800 rounded-lg transition">
                        <Mail size={18} className="text-gray-600 dark:text-gray-400" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* Back to Top Button */}
        {showBackToTop && (
          <button
            onClick={scrollToTop}
            className="fixed bottom-8 right-8 bg-blue-600 hover:bg-blue-700 text-white p-3 rounded-full shadow-lg hover:shadow-xl transition"
            aria-label="Back to top"
          >
            <ArrowUp size={24} />
          </button>
        )}

        {/* Footer */}
        <footer className={`border-t ${borderColor} mt-16 py-12 px-6`}>
          <div className="max-w-6xl mx-auto grid grid-cols-1 md:grid-cols-3 gap-8">
            <div>
              <h3 className="font-bold text-lg mb-3">Business Management Club</h3>
              <p className="text-gray-600 dark:text-gray-400">Leading the next generation of business leaders</p>
            </div>
            <div>
              <h4 className="font-semibold mb-3">Quick Links</h4>
              <div className="space-y-2 text-sm text-gray-600 dark:text-gray-400">
                <p className="cursor-pointer hover:text-blue-600">About Us</p>
                <p className="cursor-pointer hover:text-blue-600">Membership</p>
                <p className="cursor-pointer hover:text-blue-600">Archive</p>
              </div>
            </div>
            <div>
              <h4 className="font-semibold mb-3">Connect</h4>
              <p className="text-sm text-gray-600 dark:text-gray-400">📧 contact@bmc.sis.edu</p>
              <p className="text-sm text-gray-600 dark:text-gray-400">📍 Singapore International School, Mumbai</p>
            </div>
          </div>
          <div className="max-w-6xl mx-auto mt-8 pt-8 border-t border-gray-200 dark:border-gray-800 text-center text-sm text-gray-600 dark:text-gray-400">
            <p>© 2024 Business Management Club. All rights reserved.</p>
          </div>
        </footer>
      </div>
    </div>
  );
}
