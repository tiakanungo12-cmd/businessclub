# Business Management Club Website

A modern, responsive website for the Business Management Club at Singapore International School.

## Features

- ✅ Home page with hero section and upcoming events
- ✅ Blog section (Insights) for club articles
- ✅ Career Hub with resources for business education
- ✅ Shark Tank event page with application form
- ✅ Help Desk for student questions
- ✅ Team member showcase
- ✅ Dark mode toggle
- ✅ Fully responsive design
- ✅ Smooth animations and transitions

## Tech Stack

- **React 18** - Frontend library
- **Vite** - Build tool
- **Tailwind CSS** - Styling
- **Lucide React** - Icons

## Local Development

### Prerequisites
- Node.js (v14 or higher)
- npm or yarn

### Setup Instructions

1. **Clone the repository** (or download the files)
   ```bash
   cd bmc-website
   ```

2. **Install dependencies**
   ```bash
   npm install
   ```

3. **Start the development server**
   ```bash
   npm run dev
   ```

4. **Open in browser**
   - Visit `http://localhost:5173` (or the URL shown in your terminal)

5. **Build for production**
   ```bash
   npm run build
   ```

## Deployment Guide

### Option 1: Vercel (Recommended) ⭐

**Easiest option - 5 minutes to live**

1. **Create a GitHub account** (if you don't have one)
   - Go to [github.com](https://github.com)
   - Sign up for free

2. **Push code to GitHub**
   ```bash
   git init
   git add .
   git commit -m "Initial commit"
   git branch -M main
   git remote add origin https://github.com/YOUR-USERNAME/bmc-website.git
   git push -u origin main
   ```

3. **Deploy on Vercel**
   - Go to [vercel.com](https://vercel.com)
   - Sign up with GitHub
   - Click "Import Project"
   - Select your `bmc-website` repository
   - Click "Deploy"
   - Your site is live! 🎉

4. **Add custom domain** (optional)
   - Buy a domain at [namecheap.com](https://namecheap.com) (~$8-12/year)
   - Go to your Vercel project settings
   - Add domain and follow DNS instructions

### Option 2: Netlify

1. **Create Netlify account** at [netlify.com](https://netlify.com)
2. **Connect GitHub** and authorize Netlify
3. **Select repository** and click "Deploy"
4. Done! Your site is live

### Option 3: GitHub Pages (Free but Limited)

1. **Create a new repository** named `yourusername.github.io`
2. **Push code to main branch**
3. **Your site is automatically live** at `yourusername.github.io`

## File Structure

```
bmc-website/
├── src/
│   ├── App.jsx          # Main component with all pages
│   ├── main.jsx         # React entry point
│   └── index.css        # Tailwind CSS
├── index.html           # HTML entry point
├── package.json         # Dependencies and scripts
├── vite.config.js       # Vite configuration
└── README.md           # This file
```

## Customization Guide

### Change Club Name
Edit `index.html` and `src/App.jsx`:
- Line 6 in index.html: `<title>` tag
- Search for "BMC" and "Business Management Club" in App.jsx

### Update Contact Information
In `src/App.jsx`:
- Search for `contact@bmc.sis.edu` and replace with actual email
- Update phone number and address in sidebar and footer

### Add Real Team Members
In `src/App.jsx` (OUR TEAM section):
- Replace names, roles, and bios
- Change initials in the avatar circles
- Add LinkedIn and email links

### Add Blog Posts
In `src/App.jsx` (INSIGHTS section):
- Update article titles, authors, dates, and excerpts
- Replace emoji placeholders with actual cover images

### Customize Colors
The website uses:
- Navy Blue (primary): `from-blue-900 to-blue-800`
- Gold (accent): `from-yellow-400 to-yellow-300`

To change colors, search and replace throughout `App.jsx`

### Add Images
1. Create an `/public` folder in root
2. Add your images there
3. Reference in code: `<img src="/your-image.jpg" />`

## Environment Variables

For form submissions, you may need:
- Email service (Formspree, SendGrid, etc.)
- Database (Firebase, Airtable, etc.)

Setup guides coming soon!

## Form Submissions

Currently, forms don't submit anywhere. To enable:

### Option 1: Formspree (Easiest)
1. Go to [formspree.io](https://formspree.io)
2. Create account and form
3. In `App.jsx`, change form `action` attribute to your Formspree URL

### Option 2: Firebase
1. Set up Firebase project
2. Add authentication and database
3. Implement form handlers in `App.jsx`

### Option 3: Backend Service
Build a simple Node.js/Express backend to handle forms

## Troubleshooting

**Issue: "npm command not found"**
- Install Node.js from [nodejs.org](https://nodejs.org)

**Issue: Port 5173 already in use**
- Change port: `npm run dev -- --port 3000`

**Issue: Dependencies won't install**
- Clear cache: `npm cache clean --force`
- Try again: `npm install`

**Issue: Build fails on deploy**
- Check you have `package.json` and all files
- Ensure `npm install` works locally first

## Support & Resources

- **Vite Docs**: [vitejs.dev](https://vitejs.dev)
- **React Docs**: [react.dev](https://react.dev)
- **Tailwind CSS**: [tailwindcss.com](https://tailwindcss.com)
- **Vercel Docs**: [vercel.com/docs](https://vercel.com/docs)

## License

This project is free to use and modify for the Business Management Club.

---

**Questions?** Feel free to ask! This website is fully customizable to your needs.
