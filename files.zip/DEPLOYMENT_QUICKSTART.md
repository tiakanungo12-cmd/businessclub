# 🚀 Deploy Your Website in 5 Minutes

Follow this simple step-by-step guide to get your Business Management Club website live online.

## Step 1: Download Your Project

All your website files are in the `bmc-website` folder. 

**Make sure you have:**
- ✅ `package.json`
- ✅ `vite.config.js`
- ✅ `index.html`
- ✅ `src/` folder with files inside
- ✅ `.gitignore`

## Step 2: Create a GitHub Account (Free)

1. Go to [github.com](https://github.com)
2. Click "Sign up"
3. Create an account (takes 2 minutes)

## Step 3: Upload Your Code to GitHub

### Using Git (Command Line)

1. **Open Terminal/Command Prompt** and navigate to your project:
   ```bash
   cd path/to/bmc-website
   ```

2. **Initialize git** (one time only):
   ```bash
   git init
   git add .
   git commit -m "Initial commit"
   git branch -M main
   ```

3. **Create new repository on GitHub:**
   - Go to [github.com/new](https://github.com/new)
   - Name it `bmc-website`
   - Click "Create repository"
   - Copy the code shown under "push an existing repository"

4. **Push your code:**
   ```bash
   git remote add origin https://github.com/YOUR-USERNAME/bmc-website.git
   git push -u origin main
   ```

### Alternative: Upload Without Git (Easier)

If you're not comfortable with command line:

1. Go to [github.com/new](https://github.com/new)
2. Name it `bmc-website`
3. Check "Add a README file"
4. Click "Create repository"
5. Click "Upload files"
6. Drag and drop your project files
7. Click "Commit changes"

## Step 4: Deploy on Vercel (Easiest)

1. Go to [vercel.com](https://vercel.com)
2. Click "Sign up" → Select "Continue with GitHub"
3. Authorize Vercel to access your GitHub
4. Click "Import Project"
5. Select `bmc-website` repository
6. Click "Deploy"

**Your website is LIVE!** 🎉

You'll get a URL like: `bmc-website.vercel.app`

## Step 5: Get Your Own Domain Name (Optional)

Want a custom domain like `bmc.sis.edu` or `businessclub.com`?

1. **Buy a domain** at [namecheap.com](https://namecheap.com)
   - Usually $8-12/year
   - Search for your domain name
   - Add to cart and checkout

2. **Connect to Vercel:**
   - Go to your Vercel project settings
   - Click "Domains"
   - Add your domain name
   - Follow the DNS instructions (Vercel will explain)
   - Wait 24-48 hours for it to activate

3. **Your site is now at your domain!** ✨

---

## Troubleshooting

### "I don't have Git installed"
1. Download from [git-scm.com](https://git-scm.com)
2. Run the installer
3. Restart Terminal/Command Prompt

### "Command not recognized"
- Make sure you're in the correct folder
- Try: `cd /path/to/bmc-website`

### "Deploy failed"
- Check you pushed all files to GitHub
- Ensure `package.json` exists in root
- Verify `.gitignore` is in place

### "Still stuck?"
- Follow the alternative upload method (without Git)
- It's faster and easier!

---

## After Deployment

### Making Changes

1. **Edit files** on your computer
2. **Upload to GitHub:**
   ```bash
   git add .
   git commit -m "Updated content"
   git push
   ```
3. **Vercel auto-deploys!** Changes live in 1-2 minutes

### Update Contact Info

Edit `src/App.jsx`:
- Search for `contact@bmc.sis.edu`
- Replace with your actual email
- Push changes to GitHub

### Add Team Members

In `src/App.jsx`, find the "OUR TEAM" section:
- Update names, roles, and bios
- Change the initials

---

## Common Next Steps

- [ ] Update club contact information
- [ ] Add real team member names and bios
- [ ] Replace placeholder blog posts with real articles
- [ ] Add your club logo (put image in `/public` folder)
- [ ] Connect form submissions to email service
- [ ] Buy a custom domain name
- [ ] Share your website URL with everyone!

---

## Final Checklist Before Launch

- ✅ Website is live on Vercel
- ✅ Contact email is correct
- ✅ Team members are updated
- ✅ No placeholder text remaining
- ✅ Domain name is registered (optional)
- ✅ Tested on mobile and desktop

**You're done!** Your website is live and ready to show the world! 🚀

---

**Need more help?**
- Vercel Docs: [vercel.com/docs](https://vercel.com/docs)
- GitHub Help: [docs.github.com](https://docs.github.com)
- React Questions: [react.dev](https://react.dev)
